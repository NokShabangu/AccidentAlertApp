package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {
FirebaseDatabase rootNode;
DatabaseReference reference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    loginName = findViewById (id.login_name);
    loginsurname = findViewById (id.login_name);
    loginemail = findViewById (id.login_name);
    loginpassword = findViewById (id.login_name);

    loginBtn. setOnClickListener (new View.OnClickListener{})
    public void onClick (View view)
    {
        rootNode = FirebaseDatabase.getInstance();
        reference = rootNode.getReference("");

         login helperClass= new login();
        reference.setValue("");

        String name = loginName.getEditText().getText().roString();
        String surname = loginsurname.getEditText().getText().roString();
        String email = loginemail.getEditText().getText().roString();
        String password = loginPassword.getEditText().getText().roString();

        login helperClass = new login (name,surname,email,password);

        reference.child (name).setValue(login);
        reference.child (surname).setValue(login);
        reference.child (email).setValue(login);
        reference.child (password).setValue(login);


    }
}